-- phpMyAdmin SQL Dump
-- version 2.11.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 18, 2010 at 10:55 AM
-- Server version: 5.0.67
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `a6040352_film`
--

-- --------------------------------------------------------

--
-- Table structure for table `lovesnips`
--

CREATE TABLE `lovesnips` (
  `title` varchar(30) NOT NULL,
  `code` text NOT NULL,
  `description` text NOT NULL,
  `catagory` varchar(30) NOT NULL,
  `contributor` varchar(30) NOT NULL,
  `revised` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `id` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=73 ;
